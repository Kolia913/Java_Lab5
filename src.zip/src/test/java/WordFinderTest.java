import org.example.TextAnalyzer;
import org.example.WordFinder;
import org.junit.Before;
import org.junit.Test;

import java.util.HashSet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class WordFinderTest {
    private WordFinder wordFinder;
    private TextAnalyzer textAnalyzer;

    @Before
    public void setUp() {
        textAnalyzer = new TextAnalyzer("This is a sample text. Is it working? Yes, it is.");
        wordFinder = new WordFinder(2);
    }

    @Test
    public void testFindWords() {
        HashSet<String> questionSentences = textAnalyzer.findQuestionSentences();

        HashSet<String> foundWords = wordFinder.findWordsInQuestions(questionSentences);

        assertEquals(2, foundWords.size());
        assertTrue(foundWords.contains("Is"));
        assertTrue(foundWords.contains("it"));
    }

}