import org.example.TextAnalyzer;
import org.junit.Before;
import org.junit.Test;

import java.util.HashSet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TextAnalyzerTest {
    private TextAnalyzer textAnalyzer;

    @Before
    public void setUp() {
        textAnalyzer = new TextAnalyzer("This is a sample text. Is it working? Yes, it is.");
    }

    @Test
    public void testFindQuestionSentences() {
        HashSet<String> questionSentences = textAnalyzer.findQuestionSentences();

        assertEquals(1, questionSentences.size());
        assertTrue(questionSentences.contains("Is it working?"));
    }
}